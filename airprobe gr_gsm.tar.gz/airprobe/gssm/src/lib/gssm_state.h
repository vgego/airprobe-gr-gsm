// $Id: gssm_state.h,v 1.1.1.1 2007-06-01 04:26:57 jl Exp $

#pragma once

typedef enum {
	state_fc,
	state_s,
	state_data
} gssm_state_t;
