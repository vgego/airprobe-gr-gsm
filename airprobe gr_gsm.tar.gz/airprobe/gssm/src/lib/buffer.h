#pragma once

static const int BUFFER_QD_SIZE =	16384;
static const int BUFFER_MM_SIZE =	16384;
