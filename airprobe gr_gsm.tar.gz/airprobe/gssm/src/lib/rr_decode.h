// $Id: rr_decode.h,v 1.1.1.1 2007-06-01 04:26:57 jl Exp $

void display_l3(unsigned char *, unsigned int);
void display_ns_l3(unsigned char *, unsigned int);
