

const char *mcc_get(int mcc);
const char *mnc_get(int mcc, int mnc);

