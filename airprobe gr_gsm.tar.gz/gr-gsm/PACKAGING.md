# Packaging gr-gsm
## This is a work in progress...

* Run the build.sh script!
